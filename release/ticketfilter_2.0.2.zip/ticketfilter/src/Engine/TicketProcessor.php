<?php

/**
 *  ------------------------------------------------------------------------
 *  TicketFilter Plugin for GLPI
 *  Copyright (C) 2023-2026 by Chris Gralike
 *  ------------------------------------------------------------------------
 *
 *  LICENSE
 *
 *  This file is part of TicketFilter plugin for GLPI.
 *
 *  TicketFilter is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  TicketFilter is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with TicketFilter. If not, see <http://www.gnu.org/licenses/>.
 *
 *  ------------------------------------------------------------------------
 *
 *  @package    TicketFilter
 *  @version    2.0.2
 *  @author     Chris Gralike
 *  @copyright  Copyright (c) 2023-2026 by Chris Gralike
 *  @license    GPLv3+
 *  @link       https://github.com/DonutsNL/ticketfilter
 *  ------------------------------------------------------------------------
 */

declare(strict_types=1);

namespace GlpiPlugin\Ticketfilter\Engine;

use CommonITILActor;
use CommonITILObject;
use ITILFollowup;
use MailCollector;
use Ticket;
use GlpiPlugin\Ticketfilter\Audit\AuditLogger;
use GlpiPlugin\Ticketfilter\Model\FilterPattern;
use Throwable;

/**
 * Service managing ticket matching, authorization verification, followup creation,
 * and state transitions.
 */
class TicketProcessor
{
    public const DEFAULT_REOPEN_TEMPLATE = 'This ticket was reopened by automated rule "{pattern_name}" (match: {match_token}, sender: {sender_email}).';
    public const DEFAULT_SOLVED_TEMPLATE = 'This ticket was marked as solved by automated rule "{pattern_name}" (keyword: {solved_token}, sender: {sender_email}).';

    /**
     * Formats an automated intervention note with compliance and non-repudiation placeholders.
     *
     * @param string $template Custom template or empty string to use default.
     * @param string $defaultTemplate Fallback default template.
     * @param array<string, string> $context Placeholder replacement dictionary.
     * @return string
     */
    public static function formatInterventionMessage(string $template, string $defaultTemplate, array $context): string
    {
        $text = trim($template);
        if ($text === '') {
            $text = $defaultTemplate;
        }

        if (!isset($context['{datetime}'])) {
            $context['{datetime}'] = date('Y-m-d H:i:s');
        }
        if (!isset($context['{date}'])) {
            $context['{date}'] = date('Y-m-d');
        }
        if (!isset($context['{time}'])) {
            $context['{time}'] = date('H:i:s');
        }

        return strtr($text, $context);
    }
    /**
     * Searches for active, non-deleted tickets containing the matched token.
     *
     * @param string $token Matched identifier token.
     * @param int $entitiesId Entity context for multi-tenancy isolation.
     * @param bool $isRecursive Whether to include recursive child entities.
     * @return array List of matched ticket IDs.
     */
    public static function searchTicketPool(string $token, int $entitiesId = 0, bool $isRecursive = true): array
    {
        global $DB;

        $ticket = new Ticket();
        $table  = $ticket->getTable();
        $escapedToken = addcslashes($token, '%_');
        $where  = [
            'name'       => ['LIKE', '%' . $escapedToken . '%'],
            'is_deleted' => 0,
        ];

        if ($entitiesId >= 0) {
            if ($isRecursive && function_exists('getSonsOf')) {
                try {
                    $entities = getSonsOf('glpi_entities', $entitiesId);
                    $where['entities_id'] = $entities;
                } catch (\Throwable $e) {
                    $where['entities_id'] = $entitiesId;
                }
            } else {
                $where['entities_id'] = $entitiesId;
            }
        }

        $results = [];
        $iterator = $DB->request([
            'SELECT' => ['id'],
            'FROM'   => $table,
            'WHERE'  => $where,
            'ORDER'  => ['id ASC'],
            'LIMIT'  => 10,
        ]);

        foreach ($iterator as $row) {
            $results[] = (int)$row['id'];
        }

        return $results;
    }

    /**
     * Extracts and normalizes an email address from raw input string.
     * Handles formats like:
     * - "user@example.com"
     * - "<user@example.com>"
     * - "First Last <user@example.com>"
     *
     * @param string $raw
     * @return string Normalized lowercase email, or empty string if invalid.
     */
    public static function cleanEmail(string $raw): string
    {
        $raw = trim($raw);
        if ($raw === '') {
            return '';
        }

        if (preg_match('/[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/', $raw, $matches)) {
            return strtolower(trim($matches[0]));
        }

        if (filter_var($raw, FILTER_VALIDATE_EMAIL)) {
            return strtolower(trim($raw));
        }

        return '';
    }

    /**
     * Extracts sender identity information from incoming ticket input.
     * Supports both web interface submissions and GLPI MailCollector incoming emails
     * with registered users or anonymous/alternative email addresses.
     *
     * @param Ticket $item Incoming ticket hook object.
     * @return array [int 'userId', string 'userEmail']
     */
    public static function extractSenderInfo(Ticket $item): array
    {
        $userId    = 0;
        $userEmail = '';

        $hasActiveMailCollector = (class_exists(FilterEngine::class) && method_exists(FilterEngine::class, 'getActiveMailCollector') && FilterEngine::getActiveMailCollector() !== null);
        $loginUserId = (class_exists(\Session::class) && method_exists(\Session::class, 'getLoginUserID')) ? (int)\Session::getLoginUserID() : 0;

        // Context 1: Interactive user session (Web UI / API).
        // Identity MUST come strictly from Session::getLoginUserID(), NEVER caller-supplied input keys!
        if ($loginUserId > 0 && !$hasActiveMailCollector) {
            $userId = $loginUserId;
            if (class_exists(\User::class)) {
                $u = new \User();
                if ($u->getFromDB($userId)) {
                    $uEmail = method_exists($u, 'getDefaultEmail') ? $u->getDefaultEmail() : '';
                    if (!empty($uEmail)) {
                        $userEmail = self::cleanEmail($uEmail);
                    }
                }
            }
            return [
                'userId'    => $userId,
                'userEmail' => $userEmail,
            ];
        }

        if (!empty($item->input['_users_id_requester'])) {
            if (is_numeric($item->input['_users_id_requester'])) {
                $userId = (int)$item->input['_users_id_requester'];
            } elseif (is_array($item->input['_users_id_requester'])) {
                $first = reset($item->input['_users_id_requester']);
                if (is_numeric($first)) {
                    $userId = (int)$first;
                }
            }
        }

        // 1. Mailgate anonymous/alternative email notification array (GLPI MailCollector)
        if (isset($item->input['_users_id_requester_notif']['alternative_email'])) {
            $alt = $item->input['_users_id_requester_notif']['alternative_email'];
            if (is_array($alt)) {
                foreach ($alt as $val) {
                    if (!empty($val) && is_string($val)) {
                        $cleaned = self::cleanEmail($val);
                        if ($cleaned !== '') {
                            $userEmail = $cleaned;
                            break;
                        }
                    }
                }
            } elseif (is_string($alt) && !empty($alt)) {
                $userEmail = self::cleanEmail($alt);
            }
        }

        // 2. Mailgate headers: _head['from']
        if ($userEmail === '' && !empty($item->input['_head']['from']) && is_string($item->input['_head']['from'])) {
            $userEmail = self::cleanEmail($item->input['_head']['from']);
        }

        // 3. Alternative requester format: _itil_requester['alternative_email']
        if ($userEmail === '' && isset($item->input['_itil_requester']['alternative_email'])) {
            $alt = $item->input['_itil_requester']['alternative_email'];
            if (is_array($alt)) {
                foreach ($alt as $val) {
                    if (!empty($val) && is_string($val)) {
                        $cleaned = self::cleanEmail($val);
                        if ($cleaned !== '') {
                            $userEmail = $cleaned;
                            break;
                        }
                    }
                }
            } elseif (is_string($alt) && !empty($alt)) {
                $userEmail = self::cleanEmail($alt);
            }
        }

        // 4. Web UI actors format: _actors['requester']
        if (isset($item->input['_actors']['requester']) && is_array($item->input['_actors']['requester'])) {
            foreach ($item->input['_actors']['requester'] as $actor) {
                if ($userId === 0 && isset($actor['items_id']) && is_numeric($actor['items_id'])) {
                    $userId = (int)$actor['items_id'];
                }
                if ($userEmail === '') {
                    if (!empty($actor['default_email'])) {
                        $userEmail = self::cleanEmail((string)$actor['default_email']);
                    } elseif (!empty($actor['alternative_email'])) {
                        $userEmail = self::cleanEmail((string)$actor['alternative_email']);
                    }
                }
            }
        }

        // 5. Fallback common email fields: 'from', '_from', 'alternative_email'
        if ($userEmail === '') {
            foreach (['from', '_from', 'alternative_email'] as $field) {
                if (!empty($item->input[$field]) && is_string($item->input[$field])) {
                    $cleaned = self::cleanEmail($item->input[$field]);
                    if ($cleaned !== '') {
                        $userEmail = $cleaned;
                        break;
                    }
                }
            }
        }

        // 6. If userId is known but email is still empty, look up registered user's email in GLPI
        if ($userId > 0 && $userEmail === '' && class_exists(\User::class)) {
            $u = new \User();
            if ($u->getFromDB($userId)) {
                $uEmail = method_exists($u, 'getDefaultEmail') ? $u->getDefaultEmail() : '';
                if (!empty($uEmail)) {
                    $userEmail = self::cleanEmail($uEmail);
                }
            }
        }

        // 7. If userId is 0 and userEmail is known, check if a GLPI user exists for this email
        if ($userId === 0 && $userEmail !== '' && class_exists(\User::class) && method_exists(\User::class, 'getOrImportByEmail')) {
            $foundId = \User::getOrImportByEmail($userEmail, false);
            if ($foundId && is_numeric($foundId) && (int)$foundId > 0) {
                $userId = (int)$foundId;
            }
        }

        return [
            'userId'    => $userId,
            'userEmail' => $userEmail,
        ];
    }

    /**
     * Verifies if the incoming sender meets the configured authorization policy
     * for the target ticket.
     *
     * @param Ticket $incomingItem Incoming ticket object.
     * @param Ticket $targetTicket Existing matched ticket.
     * @param string $policy Configured verification policy.
     * @return array [bool 'authorized', string 'reason', string 'senderEmail', int 'senderId']
     */
    public static function verifySender(Ticket $incomingItem, Ticket $targetTicket, string $policy): array
    {
        $sender = self::extractSenderInfo($incomingItem);
        $senderEmail = $sender['userEmail'];
        $senderId    = $sender['userId'];

        $hasActiveMailCollector = (class_exists(FilterEngine::class) && method_exists(FilterEngine::class, 'getActiveMailCollector') && FilterEngine::getActiveMailCollector() !== null);
        $loginUserId = (class_exists(\Session::class) && method_exists(\Session::class, 'getLoginUserID')) ? (int)\Session::getLoginUserID() : 0;
        $isInteractive = ($loginUserId > 0 && !$hasActiveMailCollector);

        // Security check for interactive (Web / API) sessions:
        // The user MUST have rights to add a followup to the target ticket!
        if ($isInteractive) {
            $canAddFollowup = false;
            if (method_exists($targetTicket, 'canAddFollowup')) {
                $canAddFollowup = (bool)$targetTicket->canAddFollowup();
            } elseif (method_exists($targetTicket, 'canAddFollowupItem')) {
                $canAddFollowup = (bool)$targetTicket->canAddFollowupItem();
            }
            if (!$canAddFollowup) {
                return [
                    'authorized'  => false,
                    'reason'      => 'Logged-in user lacks followup rights on target ticket',
                    'senderEmail' => $senderEmail,
                    'senderId'    => $senderId,
                ];
            }
        }

        if ($policy === FilterPattern::POLICY_OPEN) {
            return [
                'authorized'  => true,
                'reason'      => 'Policy is open',
                'senderEmail' => $senderEmail,
                'senderId'    => $senderId,
            ];
        }

        $userLinkClass = $targetTicket->userlinkclass ?? 'Ticket_User';
        if (!class_exists($userLinkClass)) {
            return [
                'authorized'  => false,
                'reason'      => 'User link class unavailable',
                'senderEmail' => $senderEmail,
                'senderId'    => $senderId,
            ];
        }

        $usrObj = new $userLinkClass();
        $targetActors = $usrObj->getActors((int)$targetTicket->fields['id']);

        $allowedUserIds   = [];
        $allowedEmails    = [];
        $allowedDomains   = [];

        foreach ($targetActors as $actorGroup) {
            if (!is_array($actorGroup)) {
                continue;
            }
            foreach ($actorGroup as $actor) {
                $type = (int)($actor['type'] ?? 0);

                $evaluate = false;
                if ($policy === FilterPattern::POLICY_STRICT_REQUESTER) {
                    $evaluate = ($type === CommonITILActor::REQUESTER);
                } elseif ($policy === FilterPattern::POLICY_ANY_ACTOR) {
                    $evaluate = true;
                } elseif ($policy === FilterPattern::POLICY_SAME_DOMAIN) {
                    $evaluate = ($type === CommonITILActor::REQUESTER);
                }

                if ($evaluate) {
                    if (!empty($actor['users_id'])) {
                        $uId = (int)$actor['users_id'];
                        $allowedUserIds[] = $uId;

                        // Resolve registered user's email addresses
                        if (class_exists(\User::class)) {
                            $userObj = new \User();
                            if ($userObj->getFromDB($uId)) {
                                $emails = [];
                                if (method_exists($userObj, 'getAllEmails')) {
                                    $emails = (array)$userObj->getAllEmails();
                                }
                                if (method_exists($userObj, 'getDefaultEmail')) {
                                    $def = (string)$userObj->getDefaultEmail();
                                    if ($def !== '' && !in_array($def, $emails, true)) {
                                        $emails[] = $def;
                                    }
                                }
                                foreach ($emails as $em) {
                                    $cleanedEm = self::cleanEmail((string)$em);
                                    if ($cleanedEm !== '') {
                                        $allowedEmails[] = $cleanedEm;
                                        $dom = substr(strrchr($cleanedEm, '@') ?: '', 1);
                                        if ($dom !== '') {
                                            $allowedDomains[] = $dom;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (!empty($actor['alternative_email'])) {
                        $email = self::cleanEmail((string)$actor['alternative_email']);
                        if ($email !== '') {
                            $allowedEmails[] = $email;
                            $domain = substr(strrchr($email, '@') ?: '', 1);
                            if ($domain !== '') {
                                $allowedDomains[] = $domain;
                            }
                        }
                    }
                }
            }
        }

        $allowedEmails  = array_values(array_unique($allowedEmails));
        $allowedDomains = array_values(array_unique($allowedDomains));
        $allowedUserIds = array_values(array_unique($allowedUserIds));

        if ($senderId > 0 && in_array($senderId, $allowedUserIds, true)) {
            return [
                'authorized'  => true,
                'reason'      => 'Matched existing actor user ID',
                'senderEmail' => $senderEmail,
                'senderId'    => $senderId,
            ];
        }

        if ($senderEmail !== '' && in_array($senderEmail, $allowedEmails, true)) {
            return [
                'authorized'  => true,
                'reason'      => 'Matched existing actor email address',
                'senderEmail' => $senderEmail,
                'senderId'    => $senderId,
            ];
        }

        if ($policy === FilterPattern::POLICY_SAME_DOMAIN && $senderEmail !== '') {
            $senderDomain = substr(strrchr($senderEmail, '@') ?: '', 1);
            if ($senderDomain !== '' && in_array($senderDomain, $allowedDomains, true)) {
                return [
                    'authorized'  => true,
                    'reason'      => 'Matched organization domain',
                    'senderEmail' => $senderEmail,
                    'senderId'    => $senderId,
                ];
            }
        }

        return [
            'authorized'  => false,
            'reason'      => 'Sender is not present on target ticket actors',
            'senderEmail' => $senderEmail,
            'senderId'    => $senderId,
        ];
    }

    /**
     * Executes ticket merging, reopening, and solving safely.
     *
     * @param Ticket $incomingItem Incoming ticket hook object.
     * @param Ticket $targetTicket Loaded target ticket from database.
     * @param array $pattern FilterPattern configuration row.
     * @param string $matchedToken Extracted token that triggered match.
     * @param bool $isPrivate Whether followup should be marked private.
     * @return array [bool 'success', int 'followup_id', bool 'reopened', bool 'solved', string 'status']
     */
    public static function processTicket(
        Ticket $incomingItem,
        Ticket $targetTicket,
        array $pattern,
        string $matchedToken,
        bool $isPrivate = false
    ): array {
        global $DB;

        $targetTicketId = (int)$targetTicket->fields['id'];
        $patternName    = (string)($pattern[FilterPattern::FIELD_NAME] ?? 'Unknown');
        $patternId      = (int)($pattern[FilterPattern::FIELD_ID] ?? 0);
        $reopened       = false;
        $solved         = false;
        $suppressNotif  = !empty($pattern[FilterPattern::FIELD_SUPPRESNOTIF]);
        $sender         = self::extractSenderInfo($incomingItem);
        $subject        = (string)($incomingItem->input['name'] ?? '');

        $currentStatus = (int)($targetTicket->fields['status'] ?? 0);

        if ($currentStatus === CommonITILObject::CLOSED) {
            $allowReopen = !empty($pattern[FilterPattern::FIELD_REOPENCLOSED]);
            if (!$allowReopen) {
                return [
                    'success'     => false,
                    'followup_id' => 0,
                    'reopened'    => false,
                    'solved'      => false,
                    'status'      => 'closed_reopen_disabled'
                ];
            }

            $maxAgeDays = (int)($pattern[FilterPattern::FIELD_MAX_REOPEN_AGE_DAYS] ?? 30);
            if ($maxAgeDays > 0 && !empty($targetTicket->fields['closedate'])) {
                $closedTimestamp = strtotime((string)$targetTicket->fields['closedate']);
                $ageDays = (time() - $closedTimestamp) / (60 * 60 * 24);
                if ($ageDays > $maxAgeDays) {
                    return [
                        'success'     => false,
                        'followup_id' => 0,
                        'reopened'    => false,
                        'solved'      => false,
                        'status'      => 'closed_max_age_exceeded'
                    ];
                }
            }

            $targetTicket->update([
                'id'     => $targetTicketId,
                'status' => CommonITILObject::INCOMING,
            ]);

            $reopenContent = self::formatInterventionMessage(
                (string)($pattern[FilterPattern::FIELD_REOPEN_MESSAGE_TEMPLATE] ?? ''),
                self::DEFAULT_REOPEN_TEMPLATE,
                [
                    '{pattern_name}' => $patternName,
                    '{pattern_id}'   => (string)$patternId,
                    '{match_token}'  => $matchedToken,
                    '{sender_email}' => $sender['userEmail'],
                    '{subject}'      => $subject,
                    '{ticket_id}'    => (string)$targetTicketId,
                ]
            );

            $reopenFollowup = new ITILFollowup();
            $reopenFollowup->add([
                'items_id'      => $targetTicketId,
                'itemtype'      => Ticket::class,
                'content'       => $reopenContent,
                'users_id'      => 0,
                'add_reopen'    => 1,
                'is_private'    => 1,
                '_disablenotif' => true,
            ]);
            $reopened = true;
        }

        $itilFollowup = new ITILFollowup();

        $originalContent = (string)($incomingItem->input['content'] ?? ($incomingItem->input['name'] ?? ''));

        $followupInput = [
            'items_id'      => $targetTicketId,
            'itemtype'      => Ticket::class,
            'content'       => $originalContent,
            'users_id'      => $sender['userId'],
            'is_private'    => ($isPrivate) ? 1 : (int)($pattern[FilterPattern::FIELD_IS_PRIVATE_FOLLOWUP] ?? 0),
            '_disablenotif' => $suppressNotif,
        ];

        if (isset($incomingItem->input['_filename'])) {
            $followupInput['_filename'] = $incomingItem->input['_filename'];
        }
        if (isset($incomingItem->input['_tag'])) {
            $followupInput['_tag'] = $incomingItem->input['_tag'];
        }

        $followupId = $itilFollowup->add($followupInput);
        if ($followupId === false) {
            return [
                'success'     => false,
                'followup_id' => 0,
                'reopened'    => $reopened,
                'solved'      => false,
                'status'      => 'followup_failed'
            ];
        }

        // Create an independent private followup with TicketFilter details
        // so technicians can see the rule match without exposing technical details to requesters.
        $privateSuffix = $isPrivate ? ' (' . __('private followup', 'ticketfilter') . ')' : '';
        $auditContent = sprintf(
            __('Email merged via filter rule %s (match: %s, sender: %s)%s', 'ticketfilter'),
            '<strong>' . htmlspecialchars($patternName, ENT_QUOTES, 'UTF-8') . '</strong>',
            '<code>' . htmlspecialchars($matchedToken, ENT_QUOTES, 'UTF-8') . '</code>',
            '<code>' . htmlspecialchars($sender['userEmail'], ENT_QUOTES, 'UTF-8') . '</code>',
            $privateSuffix
        );

        try {
            $auditFollowup = new ITILFollowup();
            $auditFollowup->add([
                'items_id'      => $targetTicketId,
                'itemtype'      => Ticket::class,
                'content'       => $auditContent,
                'users_id'      => 0,
                'is_private'    => 1,
                '_disablenotif' => true,
            ]);
        } catch (\Throwable $e) {
            // Ignore audit followup creation error to avoid disrupting merge flow
        }

        if (class_exists(\Log::class) && defined(\Log::class . '::HISTORY_LOG_SIMPLE_MESSAGE')) {
            try {
                \Log::history(
                    $targetTicketId,
                    Ticket::class,
                    [0, '', sprintf('TicketFilter: matched rule "%s" (token: %s)', $patternName, $matchedToken)],
                    0,
                    \Log::HISTORY_LOG_SIMPLE_MESSAGE
                );
            } catch (\Throwable $e) {
                // Ignore history logging errors in non-standard environments
            }
        }

        $enableAutoSolve = !empty($pattern[FilterPattern::FIELD_ENABLE_AUTO_SOLVE]);
        $solvedPattern   = (string)($pattern[FilterPattern::FIELD_SOLVEDMATCHSTR] ?? '');
        if ($enableAutoSolve && $solvedPattern !== '') {
            $solvedMatch = PatternMatcher::match($solvedPattern, $subject, PatternMatcher::GROUP_SOLVED);

            if ($solvedMatch['matched'] && $solvedMatch['token'] !== null) {
                $maxLen = (int)($pattern[FilterPattern::FIELD_SOLVEDMATCHSTRLEN] ?? 25);
                if (mb_strlen($solvedMatch['token']) <= $maxLen) {
                    $targetStatus = (int)($pattern[FilterPattern::FIELD_AUTO_SOLVE_STATUS] ?? CommonITILObject::SOLVED);
                    if (!in_array($targetStatus, [CommonITILObject::SOLVED, CommonITILObject::CLOSED], true)) {
                        $targetStatus = CommonITILObject::SOLVED;
                    }

                    $targetTicket->update([
                        'id'     => $targetTicketId,
                        'status' => $targetStatus,
                    ]);

                    $solvedContent = self::formatInterventionMessage(
                        (string)($pattern[FilterPattern::FIELD_SOLVED_MESSAGE_TEMPLATE] ?? ''),
                        self::DEFAULT_SOLVED_TEMPLATE,
                        [
                            '{pattern_name}' => $patternName,
                            '{pattern_id}'   => (string)$patternId,
                            '{match_token}'  => $matchedToken,
                            '{solved_token}' => (string)$solvedMatch['token'],
                            '{sender_email}' => $sender['userEmail'],
                            '{subject}'      => $subject,
                            '{ticket_id}'    => (string)$targetTicketId,
                        ]
                    );

                    $solvedFollowup = new ITILFollowup();
                    $solvedFollowup->add([
                        'items_id'      => $targetTicketId,
                        'itemtype'      => Ticket::class,
                        'content'       => $solvedContent,
                        'users_id'      => 0,
                        'is_private'    => 1,
                        '_disablenotif' => true,
                    ]);
                    $solved = true;
                }
            }
        }

        return [
            'success'     => true,
            'followup_id' => (int)$followupId,
            'reopened'    => $reopened,
            'solved'      => $solved,
            'status'      => 'success'
        ];
    }

    /**
     * Safely moves processed email from mailgate inbox to accepted archive folder.
     *
     * @param Ticket $item Incoming ticket hook object.
     * @return bool True if moved/deleted or not mailgate, false on failure.
     */
    public static function deleteMailgateEmail(Ticket $item): bool
    {
        if (!isset($item->input['_mailgate']) || !isset($item->input['_uid'])) {
            return true;
        }

        $collectorId  = (int)$item->input['_mailgate'];
        $uid          = (string)$item->input['_uid'];
        $targetFolder = defined(\MailCollector::class . '::ACCEPTED_FOLDER')
            ? \MailCollector::ACCEPTED_FOLDER
            : 'accepted';

        try {
            $mailCollector = new \MailCollector();
            if ($mailCollector->getFromDB($collectorId)) {
                $mailCollector->connect();
                $result = (bool)$mailCollector->deleteMails($uid, $targetFolder);
                if (isset($mailCollector->storage) && is_object($mailCollector->storage) && method_exists($mailCollector->storage, 'close')) {
                    try {
                        $mailCollector->storage->close();
                    } catch (\Throwable $e) {
                        // Suppress close exception
                    }
                }
                return $result;
            }
        } catch (\Throwable $e) {
            AuditLogger::logError(
                sprintf('Failed to move email to accepted folder in mailgate: %s', $e->getMessage()),
                $item->input['name'] ?? ''
            );
        }

        return false;
    }
}
